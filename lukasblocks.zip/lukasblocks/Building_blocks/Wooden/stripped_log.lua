MN = "lukasblocks:"
minetest.register_node(MN.. "stripped_log", {
	description = "Stripped log",
	groups = {choppy = 2},
	tiles = {"stripped_log.png"},
})