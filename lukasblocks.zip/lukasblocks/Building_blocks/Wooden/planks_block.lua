MN = "lukasblocks:"
minetest.register_node(MN.. "planks_block", {
	description = "Planks Block",
	groups = {choppy = 2},
	tiles = {"planks_block.png"},
})