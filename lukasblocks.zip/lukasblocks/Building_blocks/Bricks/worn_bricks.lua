MN = "lukasblocks:"
minetest.register_node(MN.. "worn_bricks", {
	description = "Worn Bricks",
	groups = {cracky = 2},
	tiles = {"worn_block_of_bricks.png"},
})