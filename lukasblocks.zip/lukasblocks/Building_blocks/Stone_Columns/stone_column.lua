MN = "lukasblocks:"
minetest.register_node(MN.. "stone_column", {
	description = "Stone Column",
	groups = {cracky = 2},
	tiles = {"column_top.png", "column_top.png", "column_side.png"},
})