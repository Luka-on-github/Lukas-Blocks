MN = "lukasblocks:"
minetest.register_node(MN.. "polished_stone_brick", {
	description = "Polished Stone Bricks",
	groups = {cracky = 2},
	tiles = {"polished_stone_brick.png"},
})